<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'ehi_db');
define('DB_USER', 'root');
define('DB_PASS', '');
define('BASE_URL', 'http://localhost/project');