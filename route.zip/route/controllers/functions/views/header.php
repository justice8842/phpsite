<!DOCTYPE html>
<html>
<head>
    <title>Insurance Management System</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; }
        .container { width: 90%; max-width: 1200px; margin: 0 auto; padding: 0 15px; }
        
        /* Header styles */
        header { background-color: #2c3e50; color: white; padding: 1rem 0; }
        .header-container { display: flex; justify-content: space-between; align-items: center; }
        .logo { font-size: 1.5rem; font-weight: bold; }
        nav ul { display: flex; list-style: none; }
        nav ul li { margin-left: 1.5rem; }
        nav ul li a { color: white; text-decoration: none; transition: color 0.3s; }
        nav ul li a:hover { color: #3498db; }
        
        /* Main content */
        main { padding: 2rem 0; }
        
        /* Dashboard styles */
        .dashboard { background: white; padding: 2rem; border-radius: 5px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        .dashboard h1 { margin-bottom: 1rem; color: #2c3e50; }
        .dashboard p { margin-bottom: 1.5rem; }
        .dashboard ul { margin-left: 1.5rem; margin-bottom: 1.5rem; }
        .dashboard ul li { margin-bottom: 0.5rem; }
        .dashboard a { color: #3498db; text-decoration: none; }
        .dashboard a:hover { text-decoration: underline; }
        
        /* Footer */
        footer { background-color: #2c3e50; color: white; padding: 1rem 0; margin-top: 2rem; }
        .footer-container { display: flex; justify-content: space-between; }
    </style>
</head>
<body>
    <header>
        <div class="container header-container">
            <div class="logo">Insurance Management</div>
            <nav>
                <ul>
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <li><a href="/dashboard">Dashboard</a></li>
                        <li><a href="/logout">Logout</a></li>
                    <?php else: ?>
                        <li><a href="/login">Login</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </header>
    
    <main class="container">