﻿<?php
session_start();
require_once ("../../src/common/DBConnection.php");

// Redirect if not logged in
if(!isset($_SESSION['user']['logged_in'])) {
    header("Location:../../index.php");
    exit();
}

$conn = new DBConnection();

// Get Agent Statistics
$activeAgents = $conn->getOne("SELECT COUNT(AgentID) AS total FROM Agents WHERE Status = 'Active'");
$inactiveAgents = $conn->getOne("SELECT COUNT(AgentID) AS total FROM Agents WHERE Status = 'Inactive'");

// Get Policy Statistics
$activePolicies = $conn->getOne("SELECT COUNT(id) AS total FROM client_policies");
$pendingPolicies = $conn->getOne("SELECT COUNT(PolicyID) AS total FROM policies WHERE Status = 'Pending'");

// Get Commission Data
$totalCommissions = $conn->getOne("SELECT SUM(Amount) AS total FROM commissions WHERE Status = 'Paid'");
$pendingCommissions = $conn->getOne("SELECT SUM(Amount) AS total FROM commissions WHERE Status = 'Pending'");

// Get Recent Activities
$recentPolicies = $conn->getAll("
    SELECT p.PolicyID, p.PolicyNumber, c.FirstName, c.LastName, 
           p.ProductID, p.CreatedAt 
    FROM policies p
    JOIN clients c ON p.ClientID = c.ClientID
    ORDER BY p.CreatedAt DESC 
    LIMIT 5
");

// Get Policy Distribution Data
$policyCategories = $conn->getAll("
    SELECT ic.Name, COUNT(p.PolicyID) AS policy_count
    FROM policies p
    JOIN insuranceproducts ip ON p.ProductID = ip.ProductID
    JOIN insurancecategories ic ON ip.CategoryID = ic.CategoryID
    GROUP BY ic.CategoryID
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Insurance Management Dashboard</title>
    <link href="../../resource/css/bootstrap.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../../resource/css/font-awesome.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../../resource/css/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../../resource/css/green.css" rel="stylesheet">
    <!-- bootstrap-progressbar -->
    <link href="../../resource/css/bootstrap-progressbar-3.3.4.css" rel="stylesheet">
    <!-- JQVMap -->
    <link href="../../resource/css/jqvmap.css" rel="stylesheet"/>
    <!-- bootstrap-daterangepicker -->
    <link href="../../resource/css/daterangepicker.css" rel="stylesheet">
    <!-- Custom Theme Style -->
    <link href="../../resource/css/custom.css" rel="stylesheet">
    
    <style>
    /* PREMIUM DASHBOARD STYLES WITH RED THEME */
    :root {
        /* Primary Colors */
        --primary: #E63946;         /* Vibrant red */
        --primary-dark: #C0392B;    /* Deeper red */
        --primary-darker: #A82315;  /* Even deeper red */
        --primary-light: #F5B7B1;   /* Soft red */
        --primary-lighter: #FADBD8; /* Very soft red */
        --primary-transparent: rgba(230, 57, 70, 0.1);
        --primary-gradient: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
        
        /* Accent Colors */
        --accent: #1D3557;          /* Deep navy */
        --accent-light: #457B9D;    /* Medium blue */
        --accent-lighter: #A8DADC;  /* Light blue */
        
        /* Text Colors */
        --text-dark: #2C3E50;       /* Almost black */
        --text-medium: #34495E;     /* Dark gray */
        --text-light: #7F8C8D;      /* Medium gray */
        --text-lighter: #95A5A6;    /* Light gray */
        --text-white: #FFFFFF;      /* White */
        
        /* Background Colors */
        --bg-light: #F8F9FA;        /* Very light gray */
        --bg-lighter: #F1F3F5;      /* Even lighter gray */
        --bg-white: #FFFFFF;        /* White */
        
        /* Status Colors */
        --success: #2ECC71;         /* Green */
        --warning: #F39C12;         /* Orange */
        --info: #3498DB;            /* Blue */
        --danger: #E74C3C;          /* Red */
        
        /* Shadows */
        --shadow-sm: 0 2px 4px rgba(0, 0, 0, 0.05);
        --shadow-md: 0 4px 8px rgba(0, 0, 0, 0.1);
        --shadow-lg: 0 8px 16px rgba(0, 0, 0, 0.1);
        --shadow-xl: 0 12px 28px rgba(0, 0, 0, 0.15);
        
        /* Transitions */
        --transition-fast: all 0.2s ease;
        --transition-normal: all 0.3s ease;
        --transition-slow: all 0.5s ease;
    }
    
    /* Base Styles */
    body {
        font-family: 'Poppins', sans-serif;
        background-color: var(--bg-light);
        color: var(--text-dark);
        font-size: 14px;
        line-height: 1.6;
    }
    
    h1, h2, h3, h4, h5, h6 {
        font-weight: 600;
        color: var(--text-dark);
    }
    
    /* Sidebar Styles */
    .left_col {
        background: var(--primary-gradient) !important;
        box-shadow: var(--shadow-lg);
    }
    
    .nav_title {
        background: rgba(255, 255, 255, 0.05) !important;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1) !important;
        height: 70px !important;
    }
    
    .nav.side-menu > li {
        margin-bottom: 8px;
    }
    
    .nav.side-menu > li > a {
        border-radius: 8px;
        margin: 0 15px;
        padding: 14px 18px;
        font-weight: 500;
        transition: var(--transition-normal);
    }
    
    .nav.side-menu > li.active > a {
        background: rgba(255, 255, 255, 0.15) !important;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
        border-left: 3px solid rgba(255, 255, 255, 0.8);
    }
    
    .nav.side-menu > li:not(.active) > a:hover {
        background: rgba(255, 255, 255, 0.05) !important;
        transform: translateX(5px);
    }
    
    /* Top Navigation */
    .top_nav {
        box-shadow: var(--shadow-md);
    }
    
    .nav_menu {
        background: var(--bg-white) !important;
        border-bottom: none !important;
        padding: 15px 20px;
    }
    
    .top_nav .nav .open > a, 
    .top_nav .nav .open > a:focus, 
    .top_nav .nav .open > a:hover, 
    .top_nav .nav > li > a:focus, 
    .top_nav .nav > li > a:hover {
        background: var(--primary-transparent) !important;
        color: var(--primary) !important;
    }
    
    /* Main Content Area */
    .right_col {
        background-color: var(--bg-light);
        padding: 30px 35px;
    }
    
    /* Page Title */
    .page-title {
        margin-bottom: 35px;
    }
    
    .page-title .title_left h3 {
        font-size: 26px;
        font-weight: 700;
        color: var(--primary);
        display: flex;
        align-items: center;
        gap: 15px;
        position: relative;
        padding-bottom: 15px;
    }
    
    .page-title .title_left h3::after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        width: 80px;
        height: 3px;
        background: var(--primary-gradient);
        border-radius: 10px;
    }
    
    .badge.bg-green {
        background: var(--primary-gradient) !important;
        padding: 8px 15px;
        font-size: 13px;
        font-weight: 600;
        border-radius: 20px;
        box-shadow: 0 4px 10px rgba(230, 57, 70, 0.3);
    }
    
    /* Stat Tiles */
    .tile_count {
        margin-bottom: 35px;
    }
    
    .tile_count .tile_stats_count {
        padding: 30px 25px;
        text-align: left;
        margin-bottom: 25px;
        border-radius: 12px;
        box-shadow: var(--shadow-lg);
        transition: var(--transition-normal);
        background: var(--bg-white);
        border-left: none;
        position: relative;
        overflow: hidden;
    }
    
    .tile_count .tile_stats_count::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 5px;
        height: 100%;
        background: var(--primary-gradient);
        border-radius: 3px;
    }
    
    .tile_count .tile_stats_count:hover {
        transform: translateY(-8px);
        box-shadow: var(--shadow-xl);
    }
    
    .tile_count .count_top {
        font-size: 16px;
        font-weight: 600;
        margin-bottom: 15px;
        color: var(--text-dark);
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    .tile_count .count_top i {
        font-size: 20px;
        color: white;
        background: var(--primary-gradient);
        width: 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 10px;
        box-shadow: 0 4px 10px rgba(230, 57, 70, 0.3);
    }
    
    .tile_count .count {
        font-size: 36px;
        font-weight: 700;
        color: var(--primary);
        margin-bottom: 8px;
        line-height: 1.2;
    }
    
    .tile_count .count_bottom {
        font-size: 14px;
        padding-top: 5px;
        color: var(--text-light);
    }
    
    .tile_count .count_bottom .green {
        color: var(--success);
        font-weight: 600;
    }
    
    .tile_count .count_bottom .red {
        color: var(--primary);
        font-weight: 600;
    }
    
    /* Panels */
    .x_panel {
        border-radius: 12px;
        box-shadow: var(--shadow-lg);
        margin-bottom: 35px;
        border: none;
        background: var(--bg-white);
        overflow: hidden;
        position: relative;
        transition: var(--transition-normal);
    }
    
    .x_panel:hover {
        box-shadow: var(--shadow-xl);
        transform: translateY(-5px);
    }
    
    .x_panel::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
        background: var(--primary-gradient);
    }
    
    .x_title {
        border-bottom: 1px solid #f0f0f0;
        padding: 20px 25px;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
    
    .x_title h2 {
        font-size: 18px;
        font-weight: 600;
        color: var(--text-dark);
        margin: 0;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    .x_title h2 i {
        color: white;
        font-size: 16px;
        background: var(--primary-gradient);
        width: 32px;
        height: 32px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 8px;
        box-shadow: 0 4px 10px rgba(230, 57, 70, 0.3);
    }
    
    .x_content {
        padding: 25px;
    }
    
    /* Panel Toolbox */
    .nav.navbar-right.panel_toolbox {
        min-width: auto;
    }
    
    .nav.navbar-right.panel_toolbox > li > a {
        padding: 8px;
        color: var(--text-light);
        border-radius: 8px;
        transition: var(--transition-normal);
    }
    
    .nav.navbar-right.panel_toolbox > li > a:hover {
        color: var(--primary);
        background-color: var(--primary-transparent);
    }
    
    /* Tables */
    .table-responsive {
        border-radius: 8px;
        overflow: hidden;
        box-shadow: var(--shadow-md);
    }
    
    .table {
        margin-bottom: 0;
    }
    
    .table-striped > tbody > tr:nth-of-type(odd) {
        background-color: var(--bg-lighter);
    }
    
    .table > thead > tr > th {
        background: var(--primary-gradient) !important;
        color: var(--text-white);
        font-weight: 600;
        padding: 15px 20px;
        border-bottom: 0;
        font-size: 14px;
        letter-spacing: 0.5px;
        text-transform: uppercase;
    }
    
    .table > tbody > tr > td {
        padding: 15px 20px;
        vertical-align: middle;
        border-top: 1px solid #f0f0f0;
        font-size: 14px;
        font-weight: 500;
        color: var(--text-medium);
    }
    
    .table > tbody > tr:hover > td {
        background-color: var(--primary-transparent);
    }
    
    /* Labels and Badges */
    .label {
        padding: 5px 10px;
        font-size: 12px;
        font-weight: 600;
        border-radius: 20px;
        display: inline-flex;
        align-items: center;
        gap: 5px;
    }
    
    .label-success {
        background: var(--primary-gradient) !important;
        box-shadow: 0 4px 10px rgba(230, 57, 70, 0.3);
    }
    
    /* Buttons */
    .btn {
        border-radius: 8px;
        font-weight: 600;
        padding: 8px 15px;
        transition: var(--transition-normal);
        text-transform: none;
        letter-spacing: 0.5px;
        box-shadow: var(--shadow-md);
    }
    
    .btn-success {
        background: var(--primary-gradient) !important;
        border-color: var(--primary) !important;
    }
    
    .btn-success:hover, .btn-success:focus, .btn-success:active {
        background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary-darker) 100%) !important;
        border-color: var(--primary-dark) !important;
        transform: translateY(-3px);
        box-shadow: 0 6px 15px rgba(230, 57, 70, 0.3) !important;
    }
    
    .btn-primary {
        background: linear-gradient(135deg, var(--accent-light) 0%, var(--accent) 100%) !important;
        border-color: var(--accent) !important;
    }
    
    .btn-primary:hover, .btn-primary:focus, .btn-primary:active {
        background: linear-gradient(135deg, var(--accent) 0%, var(--accent) 100%) !important;
        border-color: var(--accent) !important;
        transform: translateY(-3px);
        box-shadow: 0 6px 15px rgba(29, 53, 87, 0.3) !important;
    }
    
    .btn-info {
        background: linear-gradient(135deg, var(--info) 0%, #2980B9 100%) !important;
        border-color: var(--info) !important;
    }
    
    .btn-info:hover, .btn-info:focus, .btn-info:active {
        background: linear-gradient(135deg, #2980B9 0%, #2573A7 100%) !important;
        border-color: #2980B9 !important;
        transform: translateY(-3px);
        box-shadow: 0 6px 15px rgba(52, 152, 219, 0.3) !important;
    }
    
    .btn-xs {
        padding: 5px 10px;
        font-size: 12px;
        border-radius: 5px;
    }
    
    /* Quick Actions */
    .quick-actions {
        display: flex;
        flex-wrap: wrap;
        gap: 20px;
    }
    
    .quick-actions li {
        flex: 1 0 calc(33.333% - 20px);
        min-width: 120px;
    }
    
    .quick-actions .btn {
        width: 100%;
        padding: 20px 15px;
        font-weight: 600;
        border-radius: 10px;
        text-align: center;
        transition: var(--transition-normal);
        box-shadow: var(--shadow-lg);
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 10px;
    }
    
    .quick-actions .btn i {
        font-size: 24px;
        margin-bottom: 5px;
    }
    
    .quick-actions .btn:hover {
        transform: translateY(-8px);
        box-shadow: var(--shadow-xl);
    }
    
    /* Progress Bars */
    .progress {
        height: 8px;
        margin-bottom: 15px;
        box-shadow: none;
        background-color: var(--bg-lighter);
        border-radius: 10px;
        overflow: hidden;
    }
    
    .progress-bar {
        background: var(--primary-gradient) !important;
        border-radius: 10px;
    }
    
    .progress-bar.bg-blue {
        background: linear-gradient(to right, var(--info), #2980B9) !important;
    }
    
    .progress-bar.bg-purple {
        background: linear-gradient(to right, #9B59B6, #8E44AD) !important;
    }
    
    .progress-bar.bg-orange {
        background: linear-gradient(to right, var(--warning), #D35400) !important;
    }
    
    /* Widget Summary */
    .widget_summary {
        margin-bottom: 25px;
    }
    
    .w_left {
        float: left;
        text-align: left;
        font-weight: 600;
        color: var(--text-dark);
        font-size: 15px;
    }
    
    .w_center {
        float: left;
    }
    
    .w_right {
        float: left;
        text-align: right;
        font-weight: 700;
        color: var(--primary);
        font-size: 16px;
    }
    
    .w_20 {
        width: 20%;
    }
    
    .w_25 {
        width: 25%;
    }
    
    .w_55 {
        width: 55%;
    }
    
    /* Media */
    .media {
        padding: 20px 0;
        border-bottom: 1px solid #f0f0f0;
        display: flex;
        align-items: center;
    }
    
    .media:last-child {
        border-bottom: none;
        padding-bottom: 0;
    }
    
    .media:first-child {
        padding-top: 0;
    }
    
    .media-heading {
        font-weight: 600;
        color: var(--text-dark);
        margin-bottom: 8px;
        font-size: 16px;
    }
    
    /* Avatar */
    .avatar {
        width: 50px;
        height: 50px;
        background: var(--primary-gradient) !important;
        color: white;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 20px;
        font-weight: 700;
        margin-right: 20px;
        box-shadow: 0 4px 10px rgba(230, 57, 70, 0.3);
    }
    
    /* Chart Container */
    .policy-chart-container {
        padding: 20px;
        height: 350px;
    }
    
    /* Responsive Adjustments */
    @media (max-width: 1200px) {
        .right_col {
            padding: 25px;
        }
        
        .tile_count .tile_stats_count {
            padding: 25px 20px;
        }
        
        .tile_count .count {
            font-size: 30px;
        }
        
        .x_title, .x_content {
            padding: 20px;
        }
    }
    
    @media (max-width: 992px) {
        .right_col {
            padding: 20px;
        }
        
        .tile_count .tile_stats_count {
            padding: 20px 15px;
        }
        
        .tile_count .count_top i {
            width: 35px;
            height: 35px;
            font-size: 16px;
        }
        
        .tile_count .count {
            font-size: 26px;
        }
        
        .quick-actions li {
            flex: 1 0 calc(50% - 20px);
        }
    }
    
    @media (max-width: 768px) {
        .right_col {
            padding: 15px;
        }
        
        .tile_count .tile_stats_count {
            padding: 15px;
        }
        
        .tile_count .count {
            font-size: 22px;
        }
        
        .quick-actions li {
            flex: 1 0 100%;
        }
        
        .table > thead > tr > th,
        .table > tbody > tr > td {
            padding: 12px 15px;
        }
        
        .avatar {
            width: 40px;
            height: 40px;
            font-size: 16px;
        }
    }
</style>
</head>

<body class="nav-md">
<div class="container body">
    <div class="main_container">

        <?php include '../partPage/sideAndTopBarMenu.html' ?>

        <div class="right_col" role="main">
            <!-- Page Title -->
            <div class="page-title">
                <div class="title_left">
                    <h3>Insurance Management Dashboard</h3>
                </div>
                <div class="title_right">
                    <div class="pull-right">
                        <span class="badge bg-green"><i class="fa fa-calendar"></i> <?= date('F d, Y') ?></span>
                    </div>
                </div>
            </div>
            
            <div class="clearfix"></div>
            
            <!-- Top Tiles -->
            <div class="row tile_count">
                <div class="col-md-3 col-sm-6 col-xs-12 tile_stats_count">
                    <span class="count_top"><i class="fa fa-users"></i> Active Agents</span>
                    <div class="count"><?= $activeAgents['total'] ?? 0 ?></div>
                    <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i>4% </i> From last month</span>
                </div>
                
                <div class="col-md-3 col-sm-6 col-xs-12 tile_stats_count">
                    <span class="count_top"><i class="fa fa-file-text"></i> Active Policies</span>
                    <div class="count"><?= $activePolicies['total'] ?? 0 ?></div>
                    <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i>3% </i> From last month</span>
                </div>
                
                <div class="col-md-3 col-sm-6 col-xs-12 tile_stats_count">
                    <span class="count_top"><i class="fa fa-money"></i> Total Commissions</span>
                    <div class="count">GHS <?= number_format($totalCommissions['total'] ?? 0, 2) ?></div>
                    <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i>2% </i> From last month</span>
                </div>
                
                <div class="col-md-3 col-sm-6 col-xs-12 tile_stats_count">
                    <span class="count_top"><i class="fa fa-clock-o"></i> Pending Approvals</span>
                    <div class="count"><?= $pendingPolicies['total'] ?? 0 ?></div>
                    <span class="count_bottom"><i class="red"><i class="fa fa-sort-desc"></i>1% </i> From last month</span>
                </div>
            </div>

            <div class="row">
                <!-- Policy Distribution Chart -->
                <div class="col-md-8 col-sm-12 col-xs-12">
                    <div class="x_panel">
                        <div class="x_title">
                            <h2><i class="fa fa-pie-chart"></i> Policy Distribution by Category</h2>
                            <ul class="nav navbar-right panel_toolbox">
                                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                                <li><a class="close-link"><i class="fa fa-close"></i></a></li>
                            </ul>
                            <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                            <div class="policy-chart-container">
                                <canvas id="policyChart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Quick Actions -->
                <div class="col-md-4 col-sm-12 col-xs-12">
                    <div class="x_panel">
                        <div class="x_title">
                            <h2><i class="fa fa-bolt"></i> Quick Actions</h2>
                            <ul class="nav navbar-right panel_toolbox">
                                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                                <li><a class="close-link"><i class="fa fa-close"></i></a></li>
                            </ul>
                            <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                            <div class="dashboard-widget-content">
                                <ul class="list-unstyled quick-actions">
                                    <li>
                                        <a href="new_policy.php" class="btn btn-success">
                                            <i class="fa fa-plus-circle"></i> New Policy
                                        </a>
                                    </li>
                                    <li>
                                        <a href="manage_agents.php" class="btn btn-primary">
                                            <i class="fa fa-user-plus"></i> Manage Agents
                                        </a>
                                    </li>
                                    <li>
                                        <a href="reports.php" class="btn btn-info">
                                            <i class="fa fa-file-text"></i> Generate Reports
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Policies -->
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="x_panel">
                        <div class="x_title">
                            <h2><i class="fa fa-list"></i> Recent Policy Registrations</h2>
                            <ul class="nav navbar-right panel_toolbox">
                                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                                <li><a class="close-link"><i class="fa fa-close"></i></a></li>
                            </ul>
                            <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                            <div class="table-responsive">
                                <table class="table table-striped jambo_table">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Policy Number</th>
                                            <th>Client Name</th>
                                            <th>Insurance Product</th>
                                            <th>Registration Date</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $counter = 1;
                                        foreach($recentPolicies as $policy): 
                                            $product = $conn->getOne("
                                                SELECT Name 
                                                FROM insuranceproducts 
                                                WHERE ProductID = ?
                                            ", [$policy['ProductID']]);
                                        ?>
                                        <tr>
                                            <td><?= $counter++ ?></td>
                                            <td><?= htmlspecialchars($policy['PolicyNumber']) ?></td>
                                            <td><?= htmlspecialchars($policy['FirstName']) ?> <?= htmlspecialchars($policy['LastName']) ?></td>
                                            <td><?= htmlspecialchars($product['Name'] ?? 'N/A') ?></td>
                                            <td><?= date('M d, Y', strtotime($policy['CreatedAt'])) ?></td>
                                            <td><span class="label label-success">Active</span></td>
                                            <td>
                                                <a href="view_policy.php?id=<?= $policy['PolicyID'] ?>" class="btn btn-xs btn-primary"><i class="fa fa-eye"></i> View</a>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <!-- Top Performers -->
                <div class="col-md-6 col-sm-12 col-xs-12">
                    <div class="x_panel">
                        <div class="x_title">
                            <h2><i class="fa fa-trophy"></i> Top Performing Agents</h2>
                            <ul class="nav navbar-right panel_toolbox">
                                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                                <li><a class="close-link"><i class="fa fa-close"></i></a></li>
                            </ul>
                            <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                            <?php
                            $topAgents = $conn->getAll("
                                SELECT a.AgentID, a.OtherNames, SUM(c.Amount) AS total_commissions
                                FROM agents a
                                JOIN commissions c ON a.AgentID = c.AgentID
                                GROUP BY a.AgentID
                                ORDER BY total_commissions DESC
                                LIMIT 5
                            ");
                            ?>
                            <ul class="list-unstyled">
                                <?php foreach($topAgents as $index => $agent): ?>
                                <li class="media">
                                    <div class="media-left">
                                        <div class="avatar" style="width: 50px; height: 50px; background-color: #3498DB; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 20px; font-weight: bold;">
                                            <?= substr($agent['OtherNames'], 0, 1) ?>
                                        </div>
                                    </div>
                                    <div class="media-body">
                                        <h4 class="media-heading"><?= htmlspecialchars($agent['OtherNames']) ?></h4>
                                        <div class="progress">
                                            <div class="progress-bar progress-bar-success" role="progressbar" style="width: <?= 100 - ($index * 15) ?>%" aria-valuenow="<?= 100 - ($index * 15) ?>" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                        <p><strong>GHS <?= number_format($agent['total_commissions'], 2) ?></strong> in commissions</p>
                                        <small>Agent ID: <?= $agent['AgentID'] ?></small>
                                    </div>
                                </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- Performance Summary -->
                <div class="col-md-6 col-sm-12 col-xs-12">
                    <div class="x_panel">
                        <div class="x_title">
                            <h2><i class="fa fa-bar-chart"></i> Performance Summary</h2>
                            <ul class="nav navbar-right panel_toolbox">
                                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                                <li><a class="close-link"><i class="fa fa-close"></i></a></li>
                            </ul>
                            <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                            <div class="widget_summary">
                                <div class="w_left w_25">
                                    <span>Policies Sold</span>
                                </div>
                                <div class="w_center w_55">
                                    <div class="progress">
                                        <div class="progress-bar bg-green" role="progressbar" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100" style="width: 85%;">
                                        </div>
                                    </div>
                                </div>
                                <div class="w_right w_20">
                                    <span>85%</span>
                                </div>
                                <div class="clearfix"></div>
                            </div>

                            <div class="widget_summary">
                                <div class="w_left w_25">
                                    <span>Commissions</span>
                                </div>
                                <div class="w_center w_55">
                                    <div class="progress">
                                        <div class="progress-bar bg-blue" role="progressbar" aria-valuenow="78" aria-valuemin="0" aria-valuemax="100" style="width: 78%;">
                                        </div>
                                    </div>
                                </div>
                                <div class="w_right w_20">
                                    <span>78%</span>
                                </div>
                                <div class="clearfix"></div>
                            </div>

                            <div class="widget_summary">
                                <div class="w_left w_25">
                                    <span>Client Retention</span>
                                </div>
                                <div class="w_center w_55">
                                    <div class="progress">
                                        <div class="progress-bar bg-purple" role="progressbar" aria-valuenow="92" aria-valuemin="0" aria-valuemax="100" style="width: 92%;">
                                        </div>
                                    </div>
                                </div>
                                <div class="w_right w_20">
                                    <span>92%</span>
                                </div>
                                <div class="clearfix"></div>
                            </div>

                            <div class="widget_summary">
                                <div class="w_left w_25">
                                    <span>Claims Processed</span>
                                </div>
                                <div class="w_center w_55">
                                    <div class="progress">
                                        <div class="progress-bar bg-orange" role="progressbar" aria-valuenow="65" aria-valuemin="0" aria-valuemax="100" style="width: 65%;">
                                        </div>
                                    </div>
                                </div>
                                <div class="w_right w_20">
                                    <span>65%</span>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php include '../partPage/footer.html' ?>
    </div>
</div>

<!-- Scripts -->
<!-- jQuery -->
<script src="../../resource/js/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="../../resource/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="../../resource/js/fastclick.js"></script>
<!-- NProgress -->
<script src="../../resource/js/nprogress.js"></script>
<!-- Chart.js -->
<script src="../../resource/js/Chart.min.js"></script>
<!-- gauge.js -->
<script src="../../resource/js/gauge.min.js"></script>
<!-- bootstrap-progressbar -->
<script src="../../resource/js/bootstrap-progressbar.min.js"></script>
<!-- iCheck -->
<script src="../../resource/js/icheck.min.js"></script>
<!-- Skycons -->
<script src="../../resource/js/skycons.js"></script>
<!-- Flot -->
<script src="../../resource/js/jquery.flot.js"></script>
<script src="../../resource/js/jquery.flot.pie.js"></script>
<script src="../../resource/js/jquery.flot.time.js"></script>
<script src="../../resource/js/jquery.flot.stack.js"></script>
<script src="../../resource/js/jquery.flot.resize.js"></script>
<!-- Flot plugins -->
<script src="../../resource/js/jquery.flot.orderBars.js"></script>
<script src="../../resource/js/jquery.flot.spline.min.js"></script>
<script src="../../resource/js/curvedLines.js"></script>
<!-- DateJS -->
<script src="../../resource/js/date.js"></script>
<!-- JQVMap -->
<script src="../../resource/js/jquery.vmap.min.js"></script>
<script src="../../resource/js/jquery.vmap.world.js"></script>
<script src="../../resource/js/jquery.vmap.sampledata.js"></script>
<!-- bootstrap-daterangepicker -->
<script src="../../resource/js/moment.min.js"></script>
<script src="../../resource/js/daterangepicker.js"></script>
<!-- Custom Theme Scripts -->
<script src="../../resource/js/custom.min.js"></script>

<script>
    // Initialize NProgress
    $(document).ready(function() {
        NProgress.start();
        NProgress.done();
    });
    
    // Policy Distribution Chart
    const policyData = {
        labels: <?= json_encode(array_column($policyCategories, 'Name')) ?>,
        datasets: [{
            data: <?= json_encode(array_column($policyCategories, 'policy_count')) ?>,
            backgroundColor: [
                '#26B99A', '#3498DB', '#9B59B6', 
                '#E74C3C', '#F39C12', '#34495E'
            ],
            borderWidth: 0
        }]
    };

    const ctx = document.getElementById('policyChart').getContext('2d');
    new Chart(ctx, {
        type: 'doughnut',
        data: policyData,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            legend: {
                position: 'right',
                labels: {
                    fontFamily: "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif",
                    fontSize: 12,
                    padding: 20
                }
            },
            cutoutPercentage: 70,
            animation: {
                animateScale: true,
                animateRotate: true
            },
            tooltips: {
                callbacks: {
                    label: function(tooltipItem, data) {
                        const dataset = data.datasets[tooltipItem.datasetIndex];
                        const total = dataset.data.reduce((previousValue, currentValue) => previousValue + currentValue);
                        const currentValue = dataset.data[tooltipItem.index];
                        const percentage = Math.floor(((currentValue/total) * 100)+0.5);
                        return data.labels[tooltipItem.index] + ': ' + currentValue + ' (' + percentage + '%)';
                    }
                }
            }
        }
    });
    
    // Initialize Bootstrap Progressbar
    $('.progress .progress-bar').progressbar({
        display_text: 'none'
    });
    
    // Initialize Collapse/Expand functionality
    $('.collapse-link').on('click', function() {
        var $BOX_PANEL = $(this).closest('.x_panel'),
            $ICON = $(this).find('i'),
            $BOX_CONTENT = $BOX_PANEL.find('.x_content');
        
        // Toggle content
        $BOX_CONTENT.slideToggle(200);
        
        // Toggle icon
        $ICON.toggleClass('fa-chevron-up fa-chevron-down');
        
        $BOX_PANEL.toggleClass('').toggleClass('');
        
        setTimeout(function() {
            $BOX_PANEL.resize();
        }, 50);
    });
    
    // Close panel functionality
    $('.close-link').click(function () {
        var $BOX_PANEL = $(this).closest('.x_panel');
        $BOX_PANEL.remove();
    });
</script>
</body>
</html>