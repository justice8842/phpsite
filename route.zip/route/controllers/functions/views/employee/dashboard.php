<?php
require_once __DIR__ . '/../../src/common/auth_check.php';
require_once __DIR__ . '/../../src/common/DBConnection.php';

// Check if user is employee
if (!isset($_SESSION['user']) || ($_SESSION['user']['role'] !== 'Employee' && !in_array('Agent', $_SESSION['user']['roles']))) {
    header("Location: /index.php?error=unauthorized");
    exit();
}

$db = new DBConnection();
$agentId = $_SESSION['user']['id']; // Assuming employee is also an agent
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agent Dashboard | Equity Insurance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .sidebar {
            min-height: 100vh;
            background: #16a085;
        }
        .quick-action-card {
            cursor: pointer;
            transition: all 0.3s;
        }
        .quick-action-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
        .target-meter {
            height: 150px;
            width: 150px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 d-md-block sidebar collapse bg-dark text-white">
                <div class="position-sticky pt-3">
                    <div class="text-center mb-4">
                        <img src="/assets/images/logo-white.png" alt="Logo" height="40">
                        <h5 class="mt-2">Agent Dashboard</h5>
                    </div>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="#">
                                <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/views/employee/clients.php">
                                <i class="fas fa-user-tie me-2"></i>My Clients
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/views/employee/policies.php">
                                <i class="fas fa-file-contract me-2"></i>My Policies
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/views/employee/commissions.php">
                                <i class="fas fa-money-bill-wave me-2"></i>My Commissions
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/views/employee/profile.php">
                                <i class="fas fa-user-cog me-2"></i>My Profile
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">My Performance</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <span class="me-3">Welcome, <?= htmlspecialchars($_SESSION['user']['email']) ?></span>
                        <a href="/src/store/Logout.php" class="btn btn-sm btn-outline-danger">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="row mb-4">
                    <div class="col-md-3">
                        <div class="card quick-action-card text-white bg-primary mb-3">
                            <div class="card-body text-center">
                                <i class="fas fa-user-plus fa-3x mb-3"></i>
                                <h5>New Client</h5>
                                <a href="/views/employee/add_client.php" class="stretched-link"></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card quick-action-card text-white bg-success mb-3">
                            <div class="card-body text-center">
                                <i class="fas fa-file-signature fa-3x mb-3"></i>
                                <h5>New Policy</h5>
                                <a href="/views/employee/add_policy.php" class="stretched-link"></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card quick-action-card text-white bg-warning mb-3">
                            <div class="card-body text-center">
                                <i class="fas fa-search-dollar fa-3x mb-3"></i>
                                <h5>Check Commission</h5>
                                <a href="/views/employee/commissions.php" class="stretched-link"></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card quick-action-card text-white bg-info mb-3">
                            <div class="card-body text-center">
                                <i class="fas fa-chart-pie fa-3x mb-3"></i>
                                <h5>My Performance</h5>
                                <a href="/views/employee/performance.php" class="stretched-link"></a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Performance Overview -->
                <div class="row">
                    <div class="col-md-4">
                        <div class="card shadow-sm">
                            <div class="card-body text-center">
                                <div class="target-meter">
                                    <canvas id="targetChart"></canvas>
                                </div>
                                <h5 class="mt-3">Monthly Target</h5>
                                <p class="text-muted"><?= $db->getOne("SELECT COUNT(*) FROM policies WHERE AgentID = ? AND MONTH(StartDate) = MONTH(CURRENT_DATE())", [$agentId])['COUNT(*)'] ?> of 15 policies</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card shadow-sm">
                            <div class="card-header">
                                <h6>Recent Activities</h6>
                            </div>
                            <div class="card-body">
                                <ul class="list-group list-group-flush">
                                    <?php
                                    $activities = $db->getAll(
                                        "SELECT * FROM policies 
                                         WHERE AgentID = ? 
                                         ORDER BY StartDate DESC LIMIT 5",
                                        [$agentId]
                                    );
                                    foreach ($activities as $policy): ?>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <div>
                                            <strong><?= htmlspecialchars($policy['PolicyNumber']) ?></strong>
                                            <div class="text-muted small">
                                                <?= $policy['StartDate'] ?> - 
                                                GHS <?= number_format($policy['Premium'], 2) ?>
                                            </div>
                                        </div>
                                        <span class="badge bg-<?= $policy['Status'] === 'Active' ? 'success' : 'warning' ?>">
                                            <?= $policy['Status'] ?>
                                        </span>
                                    </li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Target Meter Chart
        const targetCtx = document.getElementById('targetChart').getContext('2d');
        const policyCount = <?= $db->getOne("SELECT COUNT(*) FROM policies WHERE AgentID = ? AND MONTH(StartDate) = MONTH(CURRENT_DATE())", [$agentId])['COUNT(*)'] ?>;
        const targetPercentage = Math.min(100, (policyCount / 15) * 100);
        
        const targetChart = new Chart(targetCtx, {
            type: 'doughnut',
            data: {
                labels: ['Achieved', 'Remaining'],
                datasets: [{
                    data: [targetPercentage, 100 - targetPercentage],
                    backgroundColor: [
                        targetPercentage >= 75 ? '#2ecc71' : 
                        (targetPercentage >= 50 ? '#f39c12' : '#e74c3c'),
                        '#ecf0f1'
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                cutout: '70%',
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        enabled: false
                    }
                },
                animation: {
                    animateScale: true,
                    animateRotate: true
                }
            }
        });
    </script>
</body>
</html>