<?php
require_once __DIR__ . '/../../src/common/auth_check.php';
require_once __DIR__ . '/../../src/common/DBConnection.php';
// requireRole('Manager');

$db = new DBConnection();

// Get filter parameters
$filterClient = $_GET['client'] ?? '';
$filterStatus = $_GET['status'] ?? '';
$filterMethod = $_GET['method'] ?? '';
$filterDateFrom = $_GET['date_from'] ?? '';
$filterDateTo = $_GET['date_to'] ?? '';

// Build query with filters
$query = "SELECT t.*, c.FirstName, c.LastName 
          FROM transactions t
          JOIN clients c ON t.ClientID = c.ClientID
          WHERE 1=1";
$params = [];

if (!empty($filterClient)) {
    $query .= " AND (c.FirstName LIKE ? OR c.LastName LIKE ?)";
    $params[] = "%$filterClient%";
    $params[] = "%$filterClient%";
}

if (!empty($filterStatus)) {
    $query .= " AND t.Status = ?";
    $params[] = $filterStatus;
}

if (!empty($filterMethod)) {
    $query .= " AND t.PaymentMethod = ?";
    $params[] = $filterMethod;
}

if (!empty($filterDateFrom)) {
    $query .= " AND t.TransactionDate >= ?";
    $params[] = $filterDateFrom;
}

if (!empty($filterDateTo)) {
    $query .= " AND t.TransactionDate <= ?";
    $params[] = $filterDateTo;
}

$query .= " ORDER BY t.TransactionDate DESC";
$transactions = $db->getAll($query, $params);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaction History | Equity Insurance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">
</head>
<body class="bg-light">
    <?php include '../partials/manager_nav.php'; ?>
    
    <div class="container-fluid">
        <div class="row">
            <?php include '../partials/manager_sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Transaction History</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <button class="btn btn-sm btn-outline-secondary me-2" data-bs-toggle="modal" data-bs-target="#filterModal">
                            <i class="bi bi-funnel"></i> Filters
                        </button>
                        <a href="export_transactions.php" class="btn btn-sm btn-outline-primary">
                            <i class="bi bi-download"></i> Export
                        </a>
                    </div>
                </div>

                <!-- Filter Modal -->
                <div class="modal fade" id="filterModal" tabindex="-1">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Filter Transactions</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <form method="GET">
                                <div class="modal-body">
                                    <div class="mb-3">
                                        <label class="form-label">Client Name</label>
                                        <input type="text" class="form-control" name="client" value="<?= htmlspecialchars($filterClient) ?>">
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label class="form-label">Status</label>
                                            <select class="form-select" name="status">
                                                <option value="">All Statuses</option>
                                                <option value="Success" <?= $filterStatus === 'Success' ? 'selected' : '' ?>>Success</option>
                                                <option value="Pending" <?= $filterStatus === 'Pending' ? 'selected' : '' ?>>Pending</option>
                                                <option value="Failed" <?= $filterStatus === 'Failed' ? 'selected' : '' ?>>Failed</option>
                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Payment Method</label>
                                            <select class="form-select" name="method">
                                                <option value="">All Methods</option>
                                                <option value="Mobile Money" <?= $filterMethod === 'Mobile Money' ? 'selected' : '' ?>>Mobile Money</option>
                                                <option value="Bank Transfer" <?= $filterMethod === 'Bank Transfer' ? 'selected' : '' ?>>Bank Transfer</option>
                                                <option value="Cash" <?= $filterMethod === 'Cash' ? 'selected' : '' ?>>Cash</option>
                                                <option value="Card" <?= $filterMethod === 'Card' ? 'selected' : '' ?>>Card</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label class="form-label">Date From</label>
                                            <input type="date" class="form-control" name="date_from" value="<?= htmlspecialchars($filterDateFrom) ?>">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Date To</label>
                                            <input type="date" class="form-control" name="date_to" value="<?= htmlspecialchars($filterDateTo) ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Apply Filters</button>
                                    <a href="transactions.php" class="btn btn-outline-danger">Clear Filters</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="transactionsTable" class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Transaction ID</th>
                                        <th>Client</th>
                                        <th>Amount</th>
                                        <th>Date</th>
                                        <th>Method</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($transactions as $transaction): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($transaction['TransactionID']) ?></td>
                                        <td><?= htmlspecialchars($transaction['FirstName'] . ' ' . $transaction['LastName']) ?></td>
                                        <td>GHS <?= number_format($transaction['Amount'], 2) ?></td>
                                        <td><?= date('M d, Y', strtotime($transaction['TransactionDate'])) ?></td>
                                        <td><?= htmlspecialchars($transaction['PaymentMethod']) ?></td>
                                        <td>
                                            <span class="badge bg-<?= 
                                                $transaction['Status'] === 'Success' ? 'success' : 
                                                ($transaction['Status'] === 'Pending' ? 'warning' : 'danger')
                                            ?>">
                                                <?= $transaction['Status'] ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="btn-group btn-group-sm">
                                                <a href="transaction_details.php?id=<?= $transaction['TransactionID'] ?>" class="btn btn-outline-primary">
                                                    <i class="bi bi-eye"></i>
                                                </a>
                                                <a href="receipt.php?transaction_id=<?= $transaction['TransactionID'] ?>" class="btn btn-outline-info" target="_blank">
                                                    <i class="bi bi-receipt"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <?php include '../partials/footer.php'; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#transactionsTable').DataTable({
                responsive: true,
                columnDefs: [
                    { orderable: false, targets: 6 }
                ],
                order: [[3, 'desc']]
            });
        });
    </script>
</body>
</html>