<?php
require_once __DIR__ . '/../../src/common/auth_check.php';
require_once __DIR__ . '/../../src/common/DBConnection.php';
// requireRole('Manager');

$db = new DBConnection();

// Get clients and policies for dropdowns
$clients = $db->getAll("SELECT ClientID, FirstName, LastName FROM clients ORDER BY LastName");
$policies = $db->getAll("SELECT PolicyID, PolicyNumber FROM policies WHERE Status = 'Active'");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $paymentData = [
            'ClientID' => $_POST['client_id'],
            'PolicyID' => $_POST['policy_id'],
            'Amount' => $_POST['amount'],
            'PaymentDate' => $_POST['payment_date'],
            'PaymentMethod' => $_POST['payment_method'],
            'TransactionID' => $_POST['transaction_id'],
            'Status' => 'Pending',
            'ProcessedBy' => $_SESSION['user']['id'],
            'CreatedAt' => date('Y-m-d H:i:s')
        ];

        $db->execute(
            "INSERT INTO payments 
             (ClientID, PolicyID, Amount, PaymentDate, PaymentMethod, TransactionID, Status, ProcessedBy, CreatedAt)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            array_values($paymentData)
        );

        header("Location: payments.php?success=payment_processed");
        exit();
    } catch (Exception $e) {
        $error = "Payment processing failed: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Process Payment | Equity Insurance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <?php include '../partials/manager_nav.php'; ?>
    
    <div class="container-fluid">
        <div class="row">
            <?php include '../partials/manager_sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Process Payment</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="payments.php" class="btn btn-sm btn-outline-secondary">
                            <i class="bi bi-arrow-left"></i> Back to Payments
                        </a>
                    </div>
                </div>

                <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
                <?php endif; ?>

                <div class="card mb-4">
                    <div class="card-body">
                        <form method="POST">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label for="client_id" class="form-label">Client</label>
                                    <select class="form-select" id="client_id" name="client_id" required>
                                        <option value="">Select Client</option>
                                        <?php foreach ($clients as $client): ?>
                                        <option value="<?= $client['ClientID'] ?>">
                                            <?= htmlspecialchars($client['FirstName'] . ' ' . $client['LastName']) ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label for="policy_id" class="form-label">Policy</label>
                                    <select class="form-select" id="policy_id" name="policy_id" required>
                                        <option value="">Select Policy</option>
                                        <?php foreach ($policies as $policy): ?>
                                        <option value="<?= $policy['PolicyID'] ?>">
                                            <?= htmlspecialchars($policy['PolicyNumber']) ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label for="amount" class="form-label">Amount (GHS)</label>
                                    <input type="number" step="0.01" class="form-control" id="amount" name="amount" required>
                                </div>
                                <div class="col-md-4">
                                    <label for="payment_date" class="form-label">Payment Date</label>
                                    <input type="date" class="form-control" id="payment_date" name="payment_date" required>
                                </div>
                                <div class="col-md-4">
                                    <label for="payment_method" class="form-label">Payment Method</label>
                                    <select class="form-select" id="payment_method" name="payment_method" required>
                                        <option value="Mobile Money">Mobile Money</option>
                                        <option value="Bank Transfer">Bank Transfer</option>
                                        <option value="Cash">Cash</option>
                                        <option value="Card">Card</option>
                                    </select>
                                </div>
                                <div class="col-12">
                                    <label for="transaction_id" class="form-label">Transaction ID/Reference</label>
                                    <input type="text" class="form-control" id="transaction_id" name="transaction_id" required>
                                </div>
                                <div class="col-12 mt-4">
                                    <button type="submit" class="btn btn-primary">Process Payment</button>
                                    <button type="reset" class="btn btn-outline-secondary">Reset</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <?php include '../partials/footer.php'; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Set default payment date to today
        document.getElementById('payment_date').valueAsDate = new Date();
        
        // Client-Policy relationship
        document.getElementById('client_id').addEventListener('change', function() {
            const clientId = this.value;
            const policySelect = document.getElementById('policy_id');
            
            if (clientId) {
                fetch(`/api/get_client_policies.php?client_id=${clientId}`)
                    .then(response => response.json())
                    .then(data => {
                        policySelect.innerHTML = '<option value="">Select Policy</option>';
                        data.forEach(policy => {
                            const option = document.createElement('option');
                            option.value = policy.PolicyID;
                            option.textContent = policy.PolicyNumber;
                            policySelect.appendChild(option);
                        });
                    });
            } else {
                policySelect.innerHTML = '<option value="">Select Policy</option>';
                <?php foreach ($policies as $policy): ?>
                const option = document.createElement('option');
                option.value = '<?= $policy['PolicyID'] ?>';
                option.textContent = '<?= htmlspecialchars($policy['PolicyNumber']) ?>';
                policySelect.appendChild(option);
                <?php endforeach; ?>
            }
        });
    </script>
</body>
</html>