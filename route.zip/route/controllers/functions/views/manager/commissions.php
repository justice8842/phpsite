<?php
require_once __DIR__ . '/../../src/common/auth_check.php';
require_once __DIR__ . '/../../src/common/DBConnection.php';
// requireRole('Manager');

$db = new DBConnection();

// Get report data
$salesData = $db->getAll(
    "SELECT MONTH(p.StartDate) as month, 
            COUNT(p.PolicyID) as policy_count,
            SUM(p.Premium) as total_premium,
            SUM(c.Amount) as total_commission
     FROM policies p
     LEFT JOIN commissions c ON p.PolicyID = c.PolicyID
     WHERE YEAR(p.StartDate) = YEAR(CURRENT_DATE())
     GROUP BY MONTH(p.StartDate)
     ORDER BY MONTH(p.StartDate)"
);

$agentPerformance = $db->getAll(
    "SELECT a.OtherNames, ap.TotalSales, ap.Target, ap.AchievementPercentage
     FROM agentperformance ap
     JOIN agents a ON ap.AgentID = a.AgentID
     WHERE ap.EvaluationDate = (SELECT MAX(EvaluationDate) FROM agentperformance)
     ORDER BY ap.AchievementPercentage DESC"
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports | Equity Insurance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">
</head>
<body class="bg-light">
    <?php include '../partials/manager_nav.php'; ?>
    
    <div class="container-fluid">
        <div class="row">
            <?php include '../partials/manager_sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Reports</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <div class="btn-group me-2">
                            <button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
                            <button type="button" class="btn btn-sm btn-outline-secondary">Print</button>
                        </div>
                    </div>
                </div>

                <ul class="nav nav-tabs mb-4" id="reportsTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="sales-tab" data-bs-toggle="tab" data-bs-target="#sales" type="button">
                            Sales Performance
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="agents-tab" data-bs-toggle="tab" data-bs-target="#agents" type="button">
                            Agent Performance
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="financial-tab" data-bs-toggle="tab" data-bs-target="#financial" type="button">
                            Financial Summary
                        </button>
                    </li>
                </ul>

                <div class="tab-content" id="reportsTabContent">
                    <div class="tab-pane fade show active" id="sales" role="tabpanel">
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5>Monthly Sales Performance</h5>
                            </div>
                            <div class="card-body">
                                <canvas id="salesChart" height="300"></canvas>
                            </div>
                        </div>
                    </div>
                    
                    <div class="tab-pane fade" id="agents" role="tabpanel">
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5>Agent Performance</h5>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="agentsTable" class="table table-striped table-hover">
                                        <thead>
                                            <tr>
                                                <th>Agent</th>
                                                <th>Sales (GHS)</th>
                                                <th>Target (GHS)</th>
                                                <th>Achievement</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($agentPerformance as $agent): ?>
                                            <tr>
                                                <td><?= htmlspecialchars($agent['OtherNames']) ?></td>
                                                <td><?= number_format($agent['TotalSales'], 2) ?></td>
                                                <td><?= number_format($agent['Target'], 2) ?></td>
                                                <td>
                                                    <div class="progress" style="height: 20px;">
                                                        <div class="progress-bar 
                                                            <?= $agent['AchievementPercentage'] >= 100 ? 'bg-success' : 
                                                               ($agent['AchievementPercentage'] >= 75 ? 'bg-info' : 
                                                               ($agent['AchievementPercentage'] >= 50 ? 'bg-warning' : 'bg-danger')) ?>" 
                                                            role="progressbar" 
                                                            style="width: <?= min(100, $agent['AchievementPercentage']) ?>%" 
                                                            aria-valuenow="<?= $agent['AchievementPercentage'] ?>" 
                                                            aria-valuemin="0" 
                                                            aria-valuemax="100">
                                                            <?= round($agent['AchievementPercentage']) ?>%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="tab-pane fade" id="financial" role="tabpanel">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card mb-4">
                                    <div class="card-header">
                                        <h5>Premium Income</h5>
                                    </div>
                                    <div class="card-body">
                                        <canvas id="premiumChart" height="250"></canvas>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card mb-4">
                                    <div class="card-header">
                                        <h5>Commission Payments</h5>
                                    </div>
                                    <div class="card-body">
                                        <canvas id="commissionChart" height="250"></canvas>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <?php include '../partials/footer.php'; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#agentsTable').DataTable({
                order: [[3, 'desc']]
            });
            
            // Sales Chart
            const salesCtx = document.getElementById('salesChart').getContext('2d');
            const salesChart = new Chart(salesCtx, {
                type: 'bar',
                data: {
                    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                    datasets: [
                        {
                            label: 'Policies Sold',
                            data: [12, 19, 15, 20, 17, 25, 18, 16, 21, 23, 19, 22],
                            backgroundColor: 'rgba(54, 162, 235, 0.7)'
                        },
                        {
                            label: 'Premium (GHS)',
                            data: [12000, 19000, 15000, 20000, 17000, 25000, 18000, 16000, 21000, 23000, 19000, 22000],
                            backgroundColor: 'rgba(75, 192, 192, 0.7)',
                            type: 'line',
                            yAxisID: 'y1'
                        }
                    ]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Number of Policies'
                            }
                        },
                        y1: {
                            position: 'right',
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Premium Amount (GHS)'
                            },
                            grid: {
                                drawOnChartArea: false
                            }
                        }
                    }
                }
            });
            
            // Initialize other charts similarly
        });
    </script>
</body>
</html>