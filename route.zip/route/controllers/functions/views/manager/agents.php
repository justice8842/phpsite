<?php
require_once __DIR__ . '/../../src/common/auth_check.php';
require_once __DIR__ . '/../../src/common/DBConnection.php';
// requireRole('Manager');

$db = new DBConnection();
$agents = $db->getAll("SELECT * FROM agents ORDER BY Status DESC, OtherNames ASC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Agents | Equity Insurance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include '../partials/manager_sidebar.php'; ?>
    
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Agent Management</h1>
            <div class="btn-toolbar mb-2 mb-md-0">
                <a href="add_agent.php" class="btn btn-sm btn-primary">
                    <i class="fas fa-plus me-1"></i> Add New Agent
                </a>
            </div>
        </div>

        <div class="card shadow-sm">
            <div class="card-body">
                <div class="table-responsive">
                    <table id="agentsTable" class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>Agent Code</th>
                                <th>Name</th>
                                <th>Contact</th>
                                <th>Status</th>
                                <th>Join Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($agents as $agent): ?>
                            <tr>
                                <td><?= htmlspecialchars($agent['agent_code']) ?></td>
                                <td><?= htmlspecialchars($agent['OtherNames']) ?></td>
                                <td>
                                    <div><?= htmlspecialchars($agent['MobileNo']) ?></div>
                                    <small class="text-muted"><?= htmlspecialchars($agent['Email']) ?></small>
                                </td>
                                <td>
                                    <span class="badge bg-<?= $agent['Status'] === 'Active' ? 'success' : 'secondary' ?>">
                                        <?= $agent['Status'] ?>
                                    </span>
                                </td>
                                <td><?= date('M d, Y', strtotime($agent['CreatedAt'])) ?></td>
                                <td>
                                    <a href="agent_details.php?id=<?= $agent['AgentID'] ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="edit_agent.php?id=<?= $agent['AgentID'] ?>" class="btn btn-sm btn-outline-warning">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <?php if ($agent['Status'] === 'Active'): ?>
                                    <a href="deactivate_agent.php?id=<?= $agent['AgentID'] ?>" class="btn btn-sm btn-outline-danger">
                                        <i class="fas fa-user-slash"></i>
                                    </a>
                                    <?php else: ?>
                                    <a href="activate_agent.php?id=<?= $agent['AgentID'] ?>" class="btn btn-sm btn-outline-success">
                                        <i class="fas fa-user-check"></i>
                                    </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#agentsTable').DataTable({
                responsive: true,
                columnDefs: [
                    { orderable: false, targets: 5 }
                ]
            });
        });
    </script>
</body>
</html>