<?php
require_once __DIR__ . '/../../src/common/auth_check.php';
require_once __DIR__ . '/../../src/common/DBConnection.php';
// requireRole('Manager');

$db = new DBConnection();
$policies = $db->getAll(
    "SELECT p.*, c.FirstName, c.LastName, a.OtherNames as AgentName 
     FROM policies p
     JOIN clients c ON p.ClientID = c.ClientID
     LEFT JOIN agents a ON p.AgentID = a.AgentID
     ORDER BY p.StartDate DESC"
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Policy Management | Equity Insurance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">
</head>
<body class="bg-light">
    <?php include '../partials/manager_nav.php'; ?>
    
    <div class="container-fluid">
        <div class="row">
            <?php include '../partials/manager_sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Policy Management</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="add_policy.php" class="btn btn-sm btn-primary">
                            <i class="bi bi-plus-circle"></i> New Policy
                        </a>
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="policiesTable" class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Policy #</th>
                                        <th>Client</th>
                                        <th>Agent</th>
                                        <th>Start Date</th>
                                        <th>Premium</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($policies as $policy): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($policy['PolicyNumber']) ?></td>
                                        <td><?= htmlspecialchars($policy['FirstName'] . ' ' . $policy['LastName']) ?></td>
                                        <td><?= htmlspecialchars($policy['AgentName'] ?? 'Unassigned') ?></td>
                                        <td><?= date('M d, Y', strtotime($policy['StartDate'])) ?></td>
                                        <td>GHS <?= number_format($policy['Premium'], 2) ?></td>
                                        <td>
                                            <span class="badge bg-<?= 
                                                $policy['Status'] === 'Active' ? 'success' : 
                                                ($policy['Status'] === 'Pending' ? 'warning' : 'secondary') 
                                            ?>">
                                                <?= $policy['Status'] ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="btn-group btn-group-sm">
                                                <a href="policy_details.php?number=<?= $policy['PolicyNumber'] ?>" class="btn btn-outline-primary">
                                                    <i class="bi bi-eye"></i>
                                                </a>
                                                <a href="edit_policy.php?id=<?= $policy['PolicyID'] ?>" class="btn btn-outline-warning">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <?php include '../partials/footer.php'; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#policiesTable').DataTable({
                responsive: true,
                columnDefs: [
                    { orderable: false, targets: 6 }
                ]
            });
        });
    </script>
</body>
</html>