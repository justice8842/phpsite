<?php
require_once __DIR__ . '/../../src/common/auth_check.php';
require_once __DIR__ . '/../../src/common/DBConnection.php';
// requireRole('Manager');

$db = new DBConnection();
$clients = $db->getAll("SELECT c.*, a.OtherNames as AgentName 
                        FROM clients c
                        LEFT JOIN agents a ON c.AgentID = a.AgentID
                        ORDER BY c.CreatedAt DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Clients | Equity Insurance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include '../partials/manager_sidebar.php'; ?>
    
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Client Management</h1>
            <div class="btn-toolbar mb-2 mb-md-0">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search clients...">
                    <button class="btn btn-outline-secondary" type="button">
                        <i class="fas fa-search"></i>
                    </button>
                </div>
            </div>
        </div>

        <div class="card shadow-sm">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>Client Code</th>
                                <th>Name</th>
                                <th>Agent</th>
                                <th>Contact</th>
                                <th>ID Type</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($clients as $client): ?>
                            <tr>
                                <td><?= htmlspecialchars($client['ClientCode']) ?></td>
                                <td><?= htmlspecialchars($client['FirstName'] . ' ' . $client['LastName']) ?></td>
                                <td><?= htmlspecialchars($client['AgentName'] ?? 'Unassigned') ?></td>
                                <td>
                                    <div><?= htmlspecialchars($client['PhoneNumber']) ?></div>
                                    <small class="text-muted"><?= htmlspecialchars($client['Email']) ?></small>
                                </td>
                                <td><?= htmlspecialchars($client['IDType']) ?></td>
                                <td>
                                    <a href="client_details.php?id=<?= $client['ClientID'] ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="edit_client.php?id=<?= $client['ClientID'] ?>" class="btn btn-sm btn-outline-warning">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#agentsTable').DataTable({
                responsive: true,
                columnDefs: [
                    { orderable: false, targets: 5 }
                ]
            });
        });
    </script>
</body>
</html>