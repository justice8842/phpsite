<?php
require_once __DIR__ . '/../../src/common/auth_check.php';
require_once __DIR__ . '/../../src/common/DBConnection.php';

// Check if user is manager
// if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'Manager') {
//     header("Location: /index.php?error=unauthorized");
//     exit();
// }

$db = new DBConnection();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manager Dashboard | Equity Insurance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .sidebar {
            min-height: 100vh;
            background: #2c3e50;
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,.8);
        }
        .sidebar .nav-link:hover {
            color: #fff;
            background: rgba(255,255,255,.1);
        }
        .card {
            transition: transform .2s;
        }
        .card:hover {
            transform: scale(1.02);
        }
        .stat-card {
            border-left: 4px solid #3498db;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 d-md-block sidebar collapse bg-dark text-white">
                <div class="position-sticky pt-3">
                    <div class="text-center mb-4">
                        <img src="/assets/images/logo-white.png" alt="Logo" height="40">
                        <h5 class="mt-2">Manager Dashboard</h5>
                    </div>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="#">
                                <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="agents.php">
                                <i class="fas fa-users me-2"></i>Agents
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="clients.php">
                                <i class="fas fa-user-tie me-2"></i>Clients
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="policies.php">
                                <i class="fas fa-file-contract me-2"></i>Policies
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="commissions.php">
                                <i class="fas fa-money-bill-wave me-2"></i>Commissions
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="payments.php">
                                <i class="fas fa-money-bill-wave me-2"></i>Payment
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="process_payment.php">
                                <i class="fas fa-money-bill-wave me-2"></i>payment process
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="payment_details.php">
                                <i class="fas fa-money-bill-wave me-2"></i>Payment Details
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="transactions.php">
                                <i class="fas fa-money-bill-wave me-2"></i>Transactions
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="reports.php">
                                <i class="fas fa-chart-bar me-2"></i>Reports
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Dashboard Overview</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <span class="me-3">Welcome, <?= htmlspecialchars($_SESSION['user']['email']) ?></span>
                        <a href="/src/store/Logout.php" class="btn btn-sm btn-outline-danger">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </div>
                </div>

                <!-- Stats Cards -->
                <div class="row mb-4">
                    <div class="col-md-3">
                        <div class="card stat-card shadow-sm">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h6 class="text-muted">Active Agents</h6>
                                        <h3><?= $db->getOne("SELECT COUNT(*) FROM agents WHERE Status = 'Active'")['COUNT(*)'] ?></h3>
                                    </div>
                                    <i class="fas fa-users fa-3x text-primary"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stat-card shadow-sm">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h6 class="text-muted">Total Clients</h6>
                                        <h3><?= $db->getOne("SELECT COUNT(*) FROM clients")['COUNT(*)'] ?></h3>
                                    </div>
                                    <i class="fas fa-user-tie fa-3x text-success"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stat-card shadow-sm">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h6 class="text-muted">Active Policies</h6>
                                        <h3><?= $db->getOne("SELECT COUNT(*) FROM policies WHERE Status = 'Active'")['COUNT(*)'] ?></h3>
                                    </div>
                                    <i class="fas fa-file-contract fa-3x text-warning"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stat-card shadow-sm">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h6 class="text-muted">Pending Commissions</h6>
                                        <h3><?= $db->getOne("SELECT COUNT(*) FROM commissions WHERE Status = 'Pending'")['COUNT(*)'] ?></h3>
                                    </div>
                                    <i class="fas fa-money-bill-wave fa-3x text-info"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Recent Activities and Charts -->
                <div class="row">
                    <div class="col-md-8">
                        <div class="card shadow-sm mb-4">
                            <div class="card-header">
                                <h6>Monthly Sales Performance</h6>
                            </div>
                            <div class="card-body">
                                <canvas id="salesChart" height="250"></canvas>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card shadow-sm mb-4">
                            <div class="card-header">
                                <h6>Recent Activities</h6>
                            </div>
                            <div class="card-body">
                                <ul class="list-group list-group-flush">
                                    <?php
                                    $activities = $db->getAll(
                                        "SELECT * FROM auditlogs 
                                         WHERE user_id = ? 
                                         ORDER BY created_at DESC LIMIT 5",
                                        [$_SESSION['user']['id']]
                                    );
                                    foreach ($activities as $activity): ?>
                                    <li class="list-group-item">
                                        <small class="text-muted"><?= $activity['created_at'] ?></small><br>
                                        <?= htmlspecialchars($activity['action']) ?>
                                    </li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Sales Chart
        const salesCtx = document.getElementById('salesChart').getContext('2d');
        const salesChart = new Chart(salesCtx, {
            type: 'bar',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Policies Sold',
                    data: [12, 19, 15, 20, 17, 25],
                    backgroundColor: 'rgba(54, 162, 235, 0.5)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>