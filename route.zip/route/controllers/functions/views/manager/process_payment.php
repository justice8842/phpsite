<?php
require_once __DIR__ . '/../../src/common/auth_check.php';
require_once __DIR__ . '/../../src/common/DBConnection.php';
// requireRole('Manager');

$db = new DBConnection();
$paymentId = $_GET['id'] ?? 0;

$payment = $db->getOne(
    "SELECT p.*, c.FirstName, c.LastName, c.PhoneNumber, c.Email, 
            pol.PolicyNumber, pol.Premium, u.Email as ProcessedByEmail
     FROM payments p
     JOIN clients c ON p.ClientID = c.ClientID
     JOIN policies pol ON p.PolicyID = pol.PolicyID
     LEFT JOIN users u ON p.ProcessedBy = u.UserID
     WHERE p.PaymentID = ?",
    [$paymentId]
);

if (!$payment) {
    header("Location: payments.php?error=payment_not_found");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Details | Equity Insurance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <?php include '../partials/manager_nav.php'; ?>
    
    <div class="container-fluid">
        <div class="row">
            <?php include '../partials/manager_sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Payment Details</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="payments.php" class="btn btn-sm btn-outline-secondary me-2">
                            <i class="bi bi-arrow-left"></i> Back to Payments
                        </a>
                        <a href="receipt.php?id=<?= $paymentId ?>" class="btn btn-sm btn-outline-primary" target="_blank">
                            <i class="bi bi-receipt"></i> Generate Receipt
                        </a>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5>Payment Information</h5>
                            </div>
                            <div class="card-body">
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <p><strong>Payment ID:</strong> <?= htmlspecialchars($payment['PaymentID']) ?></p>
                                        <p><strong>Amount:</strong> GHS <?= number_format($payment['Amount'], 2) ?></p>
                                        <p><strong>Date:</strong> <?= date('M d, Y H:i', strtotime($payment['PaymentDate'])) ?></p>
                                    </div>
                                    <div class="col-md-6">
                                        <p><strong>Status:</strong> 
                                            <span class="badge bg-<?= 
                                                $payment['Status'] === 'Success' ? 'success' : 
                                                ($payment['Status'] === 'Pending' ? 'warning' : 'danger')
                                            ?>">
                                                <?= $payment['Status'] ?>
                                            </span>
                                        </p>
                                        <p><strong>Method:</strong> <?= htmlspecialchars($payment['PaymentMethod']) ?></p>
                                        <p><strong>Transaction ID:</strong> <?= htmlspecialchars($payment['TransactionID']) ?></p>
                                    </div>
                                </div>
                                <p><strong>Processed By:</strong> <?= htmlspecialchars($payment['ProcessedByEmail']) ?></p>
                                <p><strong>Processed On:</strong> <?= date('M d, Y H:i', strtotime($payment['CreatedAt'])) ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5>Policy Information</h5>
                            </div>
                            <div class="card-body">
                                <p><strong>Policy Number:</strong> <?= htmlspecialchars($payment['PolicyNumber']) ?></p>
                                <p><strong>Premium Amount:</strong> GHS <?= number_format($payment['Premium'], 2) ?></p>
                                <p><strong>Client:</strong> <?= htmlspecialchars($payment['FirstName'] . ' ' . $payment['LastName']) ?></p>
                                <p><strong>Contact:</strong> <?= htmlspecialchars($payment['PhoneNumber']) ?></p>
                                <p><strong>Email:</strong> <?= htmlspecialchars($payment['Email']) ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <?php if ($payment['Status'] === 'Pending'): ?>
                <div class="card mb-4">
                    <div class="card-header">
                        <h5>Payment Verification</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="verify_payment.php">
                            <input type="hidden" name="payment_id" value="<?= $paymentId ?>">
                            <div class="mb-3">
                                <label for="verification_status" class="form-label">Verification Status</label>
                                <select class="form-select" id="verification_status" name="status" required>
                                    <option value="Success">Verify as Successful</option>
                                    <option value="Failed">Mark as Failed</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="verification_notes" class="form-label">Notes</label>
                                <textarea class="form-control" id="verification_notes" name="notes" rows="3"></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary">Submit Verification</button>
                        </form>
                    </div>
                </div>
                <?php endif; ?>
            </main>
        </div>
    </div>

    <?php include '../partials/footer.php'; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>