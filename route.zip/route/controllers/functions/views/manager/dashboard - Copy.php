<?php
require_once __DIR__ . '/../../src/common/auth_check.php';
require_once __DIR__ . '/../../src/common/DBConnection.php';
// requireRole('Manager');

$db = new DBConnection();
$agentId = $_GET['id'] ?? 0;

$agent = $db->getOne(
    "SELECT a.*, t.TeamName, h.HierarchyName 
     FROM agents a
     JOIN salesteams t ON a.SalesTeamID = t.TeamID
     JOIN salehierarchy h ON a.SaleHierarchyID = h.HierarchyID
     WHERE a.AgentID = ?", 
    [$agentId]
);

if (!$agent) {
    header("Location: agents.php?error=agent_not_found");
    exit();
}

// Get agent performance
$performance = $db->getOne(
    "SELECT * FROM agentperformance 
     WHERE AgentID = ? 
     ORDER BY EvaluationDate DESC LIMIT 1",
    [$agentId]
);

// Get agent's clients
$clients = $db->getAll(
    "SELECT COUNT(*) as total FROM clients 
     WHERE AgentID = ?",
    [$agentId]
);

// Get agent's policies
$policies = $db->getAll(
    "SELECT COUNT(*) as total, SUM(Premium) as total_premium 
     FROM policies 
     WHERE AgentID = ? AND Status = 'Active'",
    [$agentId]
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agent Details | Equity Insurance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <?php include '../partials/manager_nav.php'; ?>
    
    <div class="container-fluid">
        <div class="row">
            <?php include '../partials/manager_sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Agent Details</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="edit_agent.php?id=<?= $agentId ?>" class="btn btn-sm btn-outline-primary me-2">
                            <i class="bi bi-pencil"></i> Edit
                        </a>
                        <a href="agents.php" class="btn btn-sm btn-outline-secondary">
                            <i class="bi bi-arrow-left"></i> Back to List
                        </a>
                    </div>
                </div>

                <?php if (isset($_GET['success'])): ?>
                <div class="alert alert-success">Agent updated successfully!</div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-md-4">
                        <div class="card mb-4">
                            <div class="card-body text-center">
                                <img src="<?= !empty($agent['AgentPicture']) ? htmlspecialchars($agent['AgentPicture']) : '/assets/images/default-avatar.jpg' ?>" 
                                     class="rounded-circle mb-3" width="150" height="150" alt="Agent Photo">
                                <h4><?= htmlspecialchars($agent['OtherNames']) ?></h4>
                                <p class="text-muted"><?= htmlspecialchars($agent['agent_code']) ?></p>
                                
                                <div class="d-flex justify-content-center gap-2 mb-3">
                                    <span class="badge bg-<?= $agent['Status'] === 'Active' ? 'success' : 'secondary' ?>">
                                        <?= $agent['Status'] ?>
                                    </span>
                                    <span class="badge bg-info">
                                        <?= htmlspecialchars($agent['TeamName']) ?>
                                    </span>
                                </div>
                                
                                <div class="d-grid gap-2">
                                    <?php if ($agent['Status'] === 'Active'): ?>
                                    <a href="deactivate_agent.php?id=<?= $agentId ?>" class="btn btn-sm btn-outline-danger">
                                        <i class="bi bi-person-x"></i> Deactivate
                                    </a>
                                    <?php else: ?>
                                    <a href="activate_agent.php?id=<?= $agentId ?>" class="btn btn-sm btn-outline-success">
                                        <i class="bi bi-person-check"></i> Activate
                                    </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card mb-4">
                            <div class="card-header">
                                <h6>Quick Stats</h6>
                            </div>
                            <div class="card-body">
                                <ul class="list-group list-group-flush">
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        Clients
                                        <span class="badge bg-primary rounded-pill"><?= $clients[0]['total'] ?? 0 ?></span>
                                    </li>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        Active Policies
                                        <span class="badge bg-primary rounded-pill"><?= $policies[0]['total'] ?? 0 ?></span>
                                    </li>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        Total Premium
                                        <span class="badge bg-success">GHS <?= number_format($policies[0]['total_premium'] ?? 0, 2) ?></span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-8">
                        <div class="card mb-4">
                            <div class="card-header">
                                <h6>Personal Information</h6>
                            </div>
                            <div class="card-body">
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <p><strong>Email:</strong> <?= htmlspecialchars($agent['Email']) ?></p>
                                        <p><strong>Mobile:</strong> <?= htmlspecialchars($agent['MobileNo']) ?></p>
                                        <p><strong>Mobile Money:</strong> <?= htmlspecialchars($agent['MobileMoneyNo']) ?></p>
                                    </div>
                                    <div class="col-md-6">
                                        <p><strong>Gender:</strong> <?= htmlspecialchars($agent['Gender']) ?></p>
                                        <p><strong>Marital Status:</strong> <?= htmlspecialchars($agent['MaritalStatus']) ?></p>
                                        <p><strong>Date of Birth:</strong> <?= date('M d, Y', strtotime($agent['DateOfBirth'])) ?></p>
                                    </div>
                                </div>
                                <p><strong>Address:</strong> <?= htmlspecialchars($agent['Address']) ?></p>
                            </div>
                        </div>
                        
                        <?php if ($performance): ?>
                        <div class="card mb-4">
                            <div class="card-header">
                                <h6>Performance</h6>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-4">
                                        <p><strong>Total Sales:</strong> GHS <?= number_format($performance['TotalSales'], 2) ?></p>
                                    </div>
                                    <div class="col-md-4">
                                        <p><strong>Target:</strong> GHS <?= number_format($performance['Target'], 2) ?></p>
                                    </div>
                                    <div class="col-md-4">
                                        <p><strong>Achievement:</strong> <?= $performance['AchievementPercentage'] ?>%</p>
                                    </div>
                                </div>
                                <p><strong>Last Evaluation:</strong> <?= date('M d, Y', strtotime($performance['EvaluationDate'])) ?></p>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <?php include '../partials/footer.php'; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>