<?php
require_once __DIR__ . '/../../src/common/auth_check.php';
require_once __DIR__ . '/../../src/common/DBConnection.php';

// Check if user is supervisor
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'Supervisor') {
    header("Location: /index.php?error=unauthorized");
    exit();
}

$db = new DBConnection();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supervisor Dashboard | Equity Insurance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .sidebar {
            min-height: 100vh;
            background: #34495e;
        }
        .team-card {
            border-left: 4px solid #2ecc71;
        }
        .performance-badge {
            font-size: 0.8rem;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 d-md-block sidebar collapse bg-dark text-white">
                <div class="position-sticky pt-3">
                    <div class="text-center mb-4">
                        <img src="/assets/images/logo-white.png" alt="Logo" height="40">
                        <h5 class="mt-2">Supervisor Dashboard</h5>
                    </div>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="#">
                                <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/views/supervisor/team.php">
                                <i class="fas fa-users me-2"></i>My Team
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/views/supervisor/policies.php">
                                <i class="fas fa-file-contract me-2"></i>Team Policies
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/views/supervisor/performance.php">
                                <i class="fas fa-chart-line me-2"></i>Performance
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Team Overview</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <span class="me-3">Welcome, <?= htmlspecialchars($_SESSION['user']['email']) ?></span>
                        <a href="/src/store/Logout.php" class="btn btn-sm btn-outline-danger">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </div>
                </div>

                <!-- Team Stats -->
                <div class="row mb-4">
                    <div class="col-md-4">
                        <div class="card team-card shadow-sm">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h6 class="text-muted">Team Members</h6>
                                        <h3><?= $db->getOne("SELECT COUNT(*) FROM agents WHERE SalesTeamID IN (SELECT TeamID FROM salesteams WHERE TeamLeaderID = ?)", [$_SESSION['user']['id']])['COUNT(*)'] ?></h3>
                                    </div>
                                    <i class="fas fa-users fa-3x text-success"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card team-card shadow-sm">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h6 class="text-muted">This Month's Sales</h6>
                                        <h3>GHS <?= number_format($db->getOne("SELECT SUM(Amount) FROM commissions WHERE AgentID IN (SELECT AgentID FROM agents WHERE SalesTeamID IN (SELECT TeamID FROM salesteams WHERE TeamLeaderID = ?)) AND MONTH(CommissionDate) = MONTH(CURRENT_DATE())", [$_SESSION['user']['id']])['SUM(Amount)'] ?? 0, 2) ?></h3>
                                    </div>
                                    <i class="fas fa-chart-line fa-3x text-primary"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card team-card shadow-sm">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h6 class="text-muted">Team Target</h6>
                                        <h3>75%</h3>
                                    </div>
                                    <i class="fas fa-bullseye fa-3x text-warning"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Team Performance -->
                <div class="card shadow-sm mb-4">
                    <div class="card-header">
                        <h6>Team Performance</h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Agent</th>
                                        <th>Policies</th>
                                        <th>Premium</th>
                                        <th>Commission</th>
                                        <th>Performance</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $teamMembers = $db->getAll(
                                        "SELECT a.AgentID, a.OtherNames, 
                                         COUNT(p.PolicyID) as policy_count,
                                         SUM(p.Premium) as total_premium,
                                         SUM(c.Amount) as total_commission
                                         FROM agents a
                                         LEFT JOIN policies p ON a.AgentID = p.AgentID
                                         LEFT JOIN commissions c ON a.AgentID = c.AgentID
                                         WHERE a.SalesTeamID IN (SELECT TeamID FROM salesteams WHERE TeamLeaderID = ?)
                                         GROUP BY a.AgentID",
                                        [$_SESSION['user']['id']]
                                    );
                                    
                                    foreach ($teamMembers as $member): 
                                        $performance = min(100, ($member['policy_count'] / 15) * 100);
                                    ?>
                                    <tr>
                                        <td><?= htmlspecialchars($member['OtherNames']) ?></td>
                                        <td><?= $member['policy_count'] ?></td>
                                        <td>GHS <?= number_format($member['total_premium'] ?? 0, 2) ?></td>
                                        <td>GHS <?= number_format($member['total_commission'] ?? 0, 2) ?></td>
                                        <td>
                                            <div class="progress" style="height: 20px;">
                                                <div class="progress-bar <?= $performance > 75 ? 'bg-success' : ($performance > 50 ? 'bg-warning' : 'bg-danger') ?>" 
                                                     role="progressbar" 
                                                     style="width: <?= $performance ?>%" 
                                                     aria-valuenow="<?= $performance ?>" 
                                                     aria-valuemin="0" 
                                                     aria-valuemax="100">
                                                    <?= round($performance) ?>%
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <a href="/views/supervisor/agent_detail.php?id=<?= $member['AgentID'] ?>" class="btn btn-sm btn-outline-primary">
                                                View
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>