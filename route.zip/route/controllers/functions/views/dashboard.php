<?php require_once 'header.php'; ?>

<div class="dashboard">
    <h1>Welcome, <?= $_SESSION['user_name'] ?></h1>
    <p>Your role: <?= $_SESSION['user_role'] ?></p>
    
    <div class="actions">
        <h2>Quick Actions</h2>
        <ul>
            <?php if ($_SESSION['user_role'] === 'Admin'): ?>
                <li><a href="/admin/dashboard">Admin Dashboard</a></li>
            <?php endif; ?>
            
            <?php if ($_SESSION['user_role'] === 'Manager'): ?>
                <li><a href="/manager/dashboard">Manager Dashboard</a></li>
            <?php endif; ?>
            
            <?php if ($_SESSION['user_role'] === 'Supervisor'): ?>
                <li><a href="/supervisor/dashboard">Supervisor Dashboard</a></li>
            <?php endif; ?>
            
            <?php if ($_SESSION['user_role'] === 'Employee'): ?>
                <li><a href="/employee/dashboard">Employee Dashboard</a></li>
            <?php endif; ?>
            
            <li><a href="/logout">Logout</a></li>
        </ul>
    </div>
</div>

<?php require_once 'footer.php'; ?>