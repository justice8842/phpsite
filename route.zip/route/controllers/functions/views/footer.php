    </main>
    
    <footer>
        <div class="container footer-container">
            <p>&copy; <?= date('Y') ?> Insurance Management System</p>
            <p>Role: <?= isset($_SESSION['user_role']) ? $_SESSION['user_role'] : 'Guest' ?></p>
        </div>
    </footer>
</body>
</html>