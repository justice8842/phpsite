<?php
require_once '../auth.php';
require_once '../lib/Database.php';

class AuthController {
    public function showLogin() {
        if (isLoggedIn()) {
            header('Location: /dashboard');
            exit();
        }
        require_once '../views/login.php';
    }
    
    public function login() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = $_POST['email'] ?? '';
            $password = $_POST['password'] ?? '';
            
            if (login($email, $password)) {
                header('Location: /dashboard');
                exit();
            } else {
                $error = "Invalid email or password";
                require_once '../views/login.php';
            }
        } else {
            header('Location: /login');
            exit();
        }
    }
    
    public function logout() {
        logout();
        header('Location: /login');
        exit();
    }
    
    public function showDashboard() {
        requireAuth();
        require_once '../views/dashboard.php';
    }
    
    public function unauthorized() {
        require_once '../views/unauthorized.php';
    }
}