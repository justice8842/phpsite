<?php
require_once '../auth.php';

class SupervisorController {
    public function dashboard() {
        requireRole('Supervisor');
        require_once '../views/supervisor/dashboard.php';
    }
}