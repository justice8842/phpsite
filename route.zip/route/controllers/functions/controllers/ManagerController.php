<?php
require_once '../auth.php';

class ManagerController {
    public function dashboard() {
        requireRole('Manager');
        require_once '../views/manager/dashboard.php';
    }
}