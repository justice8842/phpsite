<?php
require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../helpers.php';

class AuthController {
    public function showLogin() {
        $error = $_SESSION['login_error'] ?? null;
        unset($_SESSION['login_error']);
        
        require_once __DIR__ . '/../views/login.php';
    }
    
    public function login() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = $_POST['email'] ?? '';
            $password = $_POST['password'] ?? '';
            
            $role = login($email, $password);
            
            if ($role) {
                header('Location: ' . base_url("$role/dashboard"));
                exit();
            } else {
                $_SESSION['login_error'] = "Invalid credentials";
                header('Location: ' . base_url('login'));
                exit();
            }
        } else {
            header('Location: ' . base_url('login'));
            exit();
        }
    }
    
    public function logout() {
        logout();
    }
    
    public function showDashboard() {
        requireAuth();
        $role = getUserRole();
        
        switch ($role) {
            case 'admin':
                header('Location: ' . base_url('admin/dashboard'));
                break;
            case 'manager':
                header('Location: ' . base_url('manager/dashboard'));
                break;
            case 'supervisor':
                header('Location: ' . base_url('supervisor/dashboard'));
                break;
            case 'employee':
                header('Location: ' . base_url('employee/dashboard'));
                break;
            default:
                header('Location: ' . base_url('unauthorized'));
        }
        exit();
    }
    
    public function unauthorized() {
        require_once __DIR__ . '/../views/unauthorized.php';
    }
}