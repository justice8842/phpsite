<?php
require_once './auth.php';

class AdminController {
    public function dashboard() {
        requireRole('Admin');
        require_once './views/admin/dashboard.php';
    }
}