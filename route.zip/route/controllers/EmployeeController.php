<?php
require_once '../auth.php';

class EmployeeController {
    public function dashboard() {
        requireRole('Employee');
        require_once '../views/employee/dashboard.php';
    }
}