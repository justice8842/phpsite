<?php
// Set HTTP response code to 404
header("HTTP/1.0 404 Not Found");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page Not Found | 404 Error</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            line-height: 1.6;
        }
        
        .container {
            text-align: center;
            max-width: 700px;
            background: white;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        
        .error-code {
            font-size: 120px;
            font-weight: 800;
            background: linear-gradient(90deg, #ff6b6b, #4ecdc4);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            margin-bottom: 20px;
            line-height: 1;
        }
        
        h1 {
            font-size: 36px;
            margin-bottom: 15px;
            color: #2d3748;
        }
        
        p {
            font-size: 18px;
            color: #4a5568;
            margin-bottom: 30px;
        }
        
        .search-box {
            display: flex;
            max-width: 500px;
            margin: 0 auto 30px;
        }
        
        .search-box input {
            flex: 1;
            padding: 15px;
            border: 2px solid #e2e8f0;
            border-radius: 8px 0 0 8px;
            font-size: 16px;
            outline: none;
            transition: border-color 0.3s;
        }
        
        .search-box input:focus {
            border-color: #4ecdc4;
        }
        
        .search-box button {
            background: #4ecdc4;
            color: white;
            border: none;
            padding: 0 25px;
            border-radius: 0 8px 8px 0;
            cursor: pointer;
            font-weight: 600;
            transition: background 0.3s;
        }
        
        .search-box button:hover {
            background: #3da89f;
        }
        
        .home-btn {
            display: inline-block;
            background: #ff6b6b;
            color: white;
            text-decoration: none;
            padding: 15px 30px;
            border-radius: 8px;
            font-weight: 600;
            transition: transform 0.3s, background 0.3s;
            margin: 10px;
        }
        
        .home-btn:hover {
            background: #e55a5a;
            transform: translateY(-3px);
        }
        
        .links {
            margin-top: 30px;
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
        }
        
        .links a {
            color: #4a5568;
            text-decoration: none;
            margin: 0 15px;
            transition: color 0.3s;
        }
        
        .links a:hover {
            color: #2b6cb0;
            text-decoration: underline;
        }
        
        .animation {
            margin: 30px auto;
            width: 150px;
            height: 150px;
            position: relative;
        }
        
        .box {
            position: absolute;
            width: 60px;
            height: 60px;
            background: #ff6b6b;
            border-radius: 50%;
            top: 0;
            left: 0;
            animation: move 4s infinite ease-in-out;
        }
        
        .box:nth-child(2) {
            background: #4ecdc4;
            animation-delay: -1s;
        }
        
        .box:nth-child(3) {
            background: #ffd166;
            animation-delay: -2s;
        }
        
        .box:nth-child(4) {
            background: #6b5b95;
            animation-delay: -3s;
        }
        
        @keyframes move {
            0%, 100% { transform: translate(0, 0); }
            25% { transform: translate(90px, 0); }
            50% { transform: translate(90px, 90px); }
            75% { transform: translate(0, 90px); }
        }
        
        @media (max-width: 768px) {
            .container {
                padding: 30px 20px;
            }
            .error-code {
                font-size: 80px;
            }
            h1 {
                font-size: 28px;
            }
            .animation {
                width: 100px;
                height: 100px;
            }
            .box {
                width: 40px;
                height: 40px;
            }
            @keyframes move {
                0%, 100% { transform: translate(0, 0); }
                25% { transform: translate(60px, 0); }
                50% { transform: translate(60px, 60px); }
                75% { transform: translate(0, 60px); }
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="error-code">404</div>
        <h1>Oops! Page Not Found</h1>
        <p>The page you're looking for might have been removed, had its name changed, or is temporarily unavailable.</p>
        
        <form class="search-box" action="search.php" method="GET">
            <input type="text" name="q" placeholder="Search our website..." aria-label="Search">
            <button type="submit">Search</button>
        </form>
        
        <div class="animation">
            <div class="box"></div>
            <div class="box"></div>
            <div class="box"></div>
            <div class="box"></div>
        </div>
        
        <a href="/" class="home-btn">Return to Homepage</a>
        
        <div class="links">
            <a href="/about">About Us</a>
            <a href="/contact">Contact</a>
            <a href="/sitemap">Sitemap</a>
            <a href="/help">Help Center</a>
        </div>
    </div>
</body>
</html>